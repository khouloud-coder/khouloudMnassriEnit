from django.apps import AppConfig


class BloodpressureConfig(AppConfig):
    name = 'bloodPressure'
