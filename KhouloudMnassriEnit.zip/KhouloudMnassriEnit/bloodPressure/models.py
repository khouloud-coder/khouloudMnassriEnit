from utils.models import AbstractTableMeta
from django.db import models
from django.contrib.auth import get_user_model



class PatientBloodPressure(AbstractTableMeta, models.Model):
    patient = models.ForeignKey(get_user_model(),
                                on_delete=models.CASCADE)

    systolicValue = models.FloatField()
    diastolicValue = models.FloatField()
    heartBeat = models.IntegerField()
