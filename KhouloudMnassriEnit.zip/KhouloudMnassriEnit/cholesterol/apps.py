from django.apps import AppConfig


class CholesterolConfig(AppConfig):
    name = 'cholesterol'
