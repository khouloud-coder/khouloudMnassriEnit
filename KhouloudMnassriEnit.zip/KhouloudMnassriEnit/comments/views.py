from rest_framework import serializers, viewsets


from .models import Comment


class CommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Comment
        fields = ('id', 'name', 'description', 'created_at', 'updated_at',)


# @permission_classes([IsAuthenticated])
class CommentViewSet(viewsets.ModelViewSet):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer
