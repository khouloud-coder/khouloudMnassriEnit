from django.contrib import admin

from .models import PatientRespiration


class PatientRespirationAdmin(admin.ModelAdmin):
    list_display = ('get_patient', 'created_at')
    search_fields = ('patient__userprofile__first_name',)

    def get_patient(self, obj):
        return obj.patient.userprofile.first_name
    get_patient.admin_order_field = 'patient'
    get_patient.short_description = 'Patient\'s Name'


admin.site.register(PatientRespiration, PatientRespirationAdmin)