from django.apps import AppConfig


class RespirationConfig(AppConfig):
    name = 'respiration'
