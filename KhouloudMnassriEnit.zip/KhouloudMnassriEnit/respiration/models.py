from utils.models import AbstractTableMeta
from django.db import models
from django.contrib.auth import get_user_model



class PatientRespiration(AbstractTableMeta, models.Model):
    patient = models.ForeignKey(get_user_model(),
                                on_delete=models.CASCADE)

    respiratoryRate = models.IntegerField()
    pao2 = models.FloatField()
    pef = models.FloatField()
