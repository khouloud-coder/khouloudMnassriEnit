import json

from django.core.exceptions import PermissionDenied
from django.contrib.auth import get_user_model
from django.shortcuts import get_object_or_404
from rest_framework import serializers, viewsets
from rest_framework.views import APIView
from rest_framework.decorators import permission_classes, api_view
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, DjangoModelPermissions
# from .permissions import ObjectPermission


from bloodPressure.models import PatientBloodPressure
from cholesterol.models import PatientCholesterol
from respiration.models import PatientRespiration
from temperature.models import PatientTemperature
from users.models import UserProfile


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = get_user_model()
        fields = ('id', 'email', 'password', 'is_patient')
        extra_kwargs = {'password': {'write_only': True, 'min_length': 8}}

    def create(self, validated_data):
        is_patient = validated_data.pop('is_patient')
        user = get_user_model().objects.create_user(**validated_data)
        user.is_patient = is_patient
        user.save()
        return user


# @permission_classes([IsAuthenticated])
class UserViewSet(viewsets.ModelViewSet):
    queryset = get_user_model().objects.all()
    serializer_class = UserSerializer

    # def list(self, request, *args, **kwargs):
    #     raise PermissionDenied()


class UserProfileSerializer(serializers.ModelSerializer):
    user = serializers.PrimaryKeyRelatedField(
                queryset=get_user_model().objects.all())

    class Meta:
        model = UserProfile
        fields = ('__all__')


# @permission_classes([IsAuthenticated])
class UserProfileView(APIView):
    def get(self, request, pk):
        profile = UserProfile.objects.get(user=request.user)
        serializer = UserProfileSerializer(profile)
        return Response(serializer.data)


#####################temperature############################################
class TemperatureSerializer(serializers.ModelSerializer):
    patient = serializers.PrimaryKeyRelatedField(
        queryset=get_user_model().objects.all())
    temperature = serializers.FloatField()

    def create(self, validated_data):
        return PatientTemperature.objects.create(**validated_data)

    class Meta:
        model = PatientTemperature
        fields = ('id', 'temperature', 'patient',)

# @permission_classes([IsAuthenticated])
class TemperatureViewSet(viewsets.ViewSet):
    def create(self, request, *args, **kwargs):
        serializer = TemperatureSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save(
                created_by=request.user,
                modified_by=request.user
            )
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)

    def list(self, request, *args, **kwargs):
        queryset = PatientTemperature.objects.filter(patient=request.user.id)
        serializer = TemperatureSerializer(queryset, many=True)
        return Response(serializer.data)


###################cholesterol#####################################
class CholesterolSerializer(serializers.ModelSerializer):
    patient = serializers.PrimaryKeyRelatedField(
        queryset=get_user_model().objects.all())
    ldl = serializers.FloatField()
    hdl = serializers.FloatField()


    def create(self, validated_data):
        return PatientCholesterol.objects.create(**validated_data)

    class Meta:
        model = PatientCholesterol
        fields = ('id', 'ldl','hdl', 'patient',)
        # read_only_fields = ['feedback', 'approved']

# @permission_classes([IsAuthenticated])
class CholesterolViewSet(viewsets.ViewSet):
    def create(self, request, *args, **kwargs):
        serializer = CholesterolSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save(
                created_by=request.user,
                modified_by=request.user
            )
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)

    def list(self, request, *args, **kwargs):
        queryset = PatientCholesterol.objects.filter(patient=request.user.id)
        serializer = CholesterolSerializer(queryset, many=True)
        return Response(serializer.data)

#################BLOOD PRESSURE#############################
class BloodPressureSerializer(serializers.ModelSerializer):
    patient = serializers.PrimaryKeyRelatedField(
        queryset=get_user_model().objects.all())
    systolicValue = serializers.FloatField()
    diastolicValue = serializers.FloatField()
    heartBeat = serializers.IntegerField()


    def create(self, validated_data):
        return PatientBloodPressure.objects.create(**validated_data)

    class Meta:
        model = PatientCholesterol
        fields = ('id', 'systolicValue','diastolicValue','heartBeat', 'patient',)
        # read_only_fields = ['feedback', 'approved']

# @permission_classes([IsAuthenticated])
class BloodPressureViewSet(viewsets.ViewSet):
    def create(self, request, *args, **kwargs):
        serializer = BloodPressureSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save(
                created_by=request.user,
                modified_by=request.user
            )
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)

    def list(self, request, *args, **kwargs):
        queryset = PatientBloodPressure.objects.filter(patient=request.user.id)
        serializer = BloodPressureSerializer(queryset, many=True)
        return Response(serializer.data)
#########################respirations########################################
class RespirationSerializer(serializers.ModelSerializer):
    patient = serializers.PrimaryKeyRelatedField(
        queryset=get_user_model().objects.all())
    respiratoryRate = serializers.IntegerField()
    pao2 = serializers.FloatField()
    pef = serializers.FloatField()

    def create(self, validated_data):
        return PatientRespiration.objects.create(**validated_data)

    class Meta:
        model = PatientCholesterol
        fields = ('id', 'respiratoryRate','pao2','pef', 'patient',)
        # read_only_fields = ['feedback', 'approved']

# @permission_classes([IsAuthenticated])
class RespirationViewSet(viewsets.ViewSet):
    def create(self, request, *args, **kwargs):
        serializer = RespirationSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save(
                created_by=request.user,
                modified_by=request.user
            )
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)

    def list(self, request, *args, **kwargs):
        queryset = PatientRespiration.objects.filter(patient=request.user.id)
        serializer = RespirationSerializer(queryset, many=True)
        return Response(serializer.data)

######################Authentication####################

class CustomAuthToken(ObtainAuthToken):
    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data,
                                           context={'request': request})
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        token, created = Token.objects.get_or_create(user=user)
        return Response({
            'token': token.key,
            'user_id': user.pk,
            'email': user.email
        })

# @api_view(['POST,'])
# def registration_view(request):
#     if request.method=='POST':
#         serializer=RespirationSerializer(data=request.data)
#         data={}
#         if serializer.is_valid():
#             user=serializer.save()
#             data['response']='successfully registered a new user'
#             data['emai']=user.email
#             data['user_id']=user.pk
#             token=Token.objects.get(user=user).key
#             data['token']=token
#         else:
#             data=serializer.errors
#         return Response(data)