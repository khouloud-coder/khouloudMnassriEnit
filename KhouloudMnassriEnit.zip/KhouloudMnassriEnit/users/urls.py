from django.urls import path,include
from rest_framework.authtoken.views import obtain_auth_token
from rest_framework_nested import routers

from .views import *

router = routers.SimpleRouter()
router.register(r'',UserViewSet)

temperatures_router = routers.NestedSimpleRouter(router, r'', lookup='list')
temperatures_router.register(
    r'temperatures',
    TemperatureViewSet,
    basename='temperatures'
)
cholesterols_router = routers.NestedSimpleRouter(router, r'', lookup='list')
cholesterols_router.register(
    r'cholesterols',
    CholesterolViewSet,
    basename='cholesterols'
)
bloodPressures_router = routers.NestedSimpleRouter(router, r'', lookup='list')
bloodPressures_router.register(
    r'bloodPressures',
    BloodPressureViewSet,
    basename='bloodPressures'
)
respiration_router = routers.NestedSimpleRouter(router, r'', lookup='list')
respiration_router.register(
    r'respirations',
    RespirationViewSet,
    basename='respirations'
)

urlpatterns = [
    path('',include(router.urls)),
    path('<int:pk>/profile/',
         UserProfileView.as_view(), name='user-profile'),
    path('', include(temperatures_router.urls)),
    path('', include(cholesterols_router.urls)),
    path('', include(bloodPressures_router.urls)),
    path('', include(respiration_router.urls)),
    # path('register',registration_view,name="register"),
    # path('login', obtain_auth_token , name="login"),

    path('login', CustomAuthToken.as_view()),

]