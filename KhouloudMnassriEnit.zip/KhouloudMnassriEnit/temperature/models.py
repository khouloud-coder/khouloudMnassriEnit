from django.db import models
from django.contrib.auth import get_user_model

from utils.models import AbstractTableMeta



class PatientTemperature(AbstractTableMeta, models.Model):
    patient = models.ForeignKey(get_user_model(),
                                on_delete=models.CASCADE)

    temperature = models.FloatField()




